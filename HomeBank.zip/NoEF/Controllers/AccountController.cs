﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NoEF.Models;
using NoEF.Repository;

namespace NoEF.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }

        // GET: Account/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Account/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Account/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Account/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Account/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Account/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Account/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        // GET: Account/GetAccounts    
        public ActionResult GetAccounts()
        {
            AccRepository AccRepo = new AccRepository();
            ModelState.Clear();
            return View(AccRepo.GetAccounts());
        }

        // GET: Account/AddAccount    
        public ActionResult AddAccount()
        {
            CurRepository CurRepo = new CurRepository();
            ViewBag.Currencies = CurRepo.GetCurrencies().Select(x=>new SelectListItem {Value = x.Id.ToString(),Text = x.Name}).ToList();
            return View();
        }

        // POST: Account/AddAccount    
        [HttpPost]
        public ActionResult AddAccount(Account Acc)
        {
            CurRepository CurRepo = new CurRepository();
            ViewBag.Currencies = CurRepo.GetCurrencies().Select(x => new SelectListItem { Value = x.Id.ToString(), Text = x.Name }).ToList();
            try
            {
                if (ModelState.IsValid)
                {
                    AccRepository AccRepo = new AccRepository();

                    if (AccRepo.AddAccount(Acc))
                    {
                        ViewBag.Message = "Account details added successfully";
                    }
                }
                return View();
            }
            catch(Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View();
            }
        }

    // GET: Account/EditAccount/5    
        public ActionResult EditAccount(int id)
        {
            CurRepository CurRepo = new CurRepository();
            ViewBag.Currencies = CurRepo.GetCurrencies().Select(x => new SelectListItem { Value = x.Id.ToString(), Text = x.Name }).ToList();
            AccRepository AccRepo = new AccRepository();
            return View(AccRepo.GetAccounts().Find(Acc => Acc.Id == id));
        }

        // POST: Account/EditAccount/5    
        [HttpPost]
        public ActionResult EditAccount(int id, Account obj)
        {
            CurRepository CurRepo = new CurRepository();
            ViewBag.Currencies = CurRepo.GetCurrencies().Select(x => new SelectListItem { Value = x.Id.ToString(), Text = x.Name }).ToList();
            try
            {
                AccRepository AccRepo = new AccRepository();
                AccRepo.UpdateAccount(obj);
                return RedirectToAction("GetAccounts");
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View();
            }
        }
        // GET: Account/DeleteAccount/5    
        public ActionResult DeleteAccount(int id)
        {
            try
            {
                AccRepository AccRepo = new AccRepository();
                if (AccRepo.DeleteAccount(id))
                {
                    ViewBag.AlertMsg = "Account details deleted successfully";

                }
                return RedirectToAction("GetAccounts");
            }
            catch
            {
                return View();
            }
        }
    }
}
