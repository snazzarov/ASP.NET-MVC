﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NoEF.Models;
using NoEF.Repository;

namespace NoEF.Controllers
{
    public class CurrencyController : Controller
    {
        // GET: Currency
        public ActionResult Index()
        {
            return View();
        }

        // GET: Currency/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Currency/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Currency/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Currency/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Currency/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Currency/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Currency/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        /*------------------------------------------------------------------------------------------------*/

        // GET: Currency/GetCurrencys    
        public ActionResult GetCurrencies()
        {
            CurRepository CurRepo = new CurRepository();
            ModelState.Clear();
            return View(CurRepo.GetCurrencies());
        }

        // GET: Currency/AddCurrency    
        public ActionResult AddCurrency()
        {
            return View();
        }

        // POST: Currency/AddCurrency    
        [HttpPost]
        public ActionResult AddCurrency(Currency Cur)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    CurRepository CurRepo = new CurRepository();

                    if (CurRepo.AddCurrency(Cur))
                    {
                        ViewBag.Message = "Currency details added successfully";
                    }
                }
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View();
            }
        }

        // GET: Currency/EditCurrency/5    
        public ActionResult EditCurrency(int id)
        {
            CurRepository CurRepo = new CurRepository();
            return View(CurRepo.GetCurrencies().Find(Cur => Cur.Id == id));
        }

        // POST: Currency/EditCurrency/5    
        [HttpPost]
        public ActionResult EditCurrency(int id, Currency obj)
        {
            try
            {
                CurRepository CurRepo = new CurRepository();
                CurRepo.UpdateCurrency(obj);
                return RedirectToAction("GetCurrencies");
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View();
            }
        }

        // GET: Currency/DeleteCurrency/5    
        public ActionResult DeleteCurrency(int id)
        {
            try
            {
                CurRepository CurRepo = new CurRepository();
                if (CurRepo.DeleteCurrency(id))
                {
                    ViewBag.AlertMsg = "Currency details deleted successfully";

                }
                return RedirectToAction("GetCurrencies");
            }
            catch
            {
                return View();
            }
        }
    }
}
